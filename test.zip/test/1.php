<?php
// outputs e.g.  somefile.txt was last modified: December 29 2002 22:16:23.


echo __FILE__,"<br />";
echo dirname(__FILE__),"<br />";
echo dirname(dirname(__FILE__)),"<br />";
//将在页面打印出一个这个文件所在绝对路径!
?>
 