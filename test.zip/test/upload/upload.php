<?php
if(@$_POST['sub']){
	
	if ((($_FILES["file"]["type"] == "image/gif")|| ($_FILES["file"]["type"] == "image/jpeg")|| ($_FILES["file"]["type"] == "image/pjpeg")))
	{
		if ($_FILES["file"]["error"] > 0)
		{
			echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
		}
		else
		{
			echo "Upload: " . $_FILES["file"]["name"] . "<br />";
			echo "Type: " . $_FILES["file"]["type"] . "<br />";
			echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
			echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
			$filename = md5(time()).$_FILES["file"]["name"];
			if (file_exists("upload/" . $filename))
			{
				echo $filename . " 上传成功 ";
			}
			else
			{
				move_uploaded_file($_FILES["file"]["tmp_name"],"upload/" .$filename);
				echo "Stored in: " . "upload/" . $filename;
			}
		}
	}else
		{
		echo "上传错误";
		}
	
	
}






?>
<meta charset="UTF-8">
<form method="post" enctype ="multipart/form-data"/>
	点这里上传文件:<input type="file" name="file"/>
	<input type="submit" value="上传" name="sub"/>
</form>
