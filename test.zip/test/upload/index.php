<!DOCTYPE html>
<html>
<head><link rel="stylesheet" type="text/css" href="../css/css.css">
	<title>上传漏洞</title>
</head>
<body>

<p><a href="./upfile.php">文件上传无验证</a>
<p><a href="./upload.php">文件上传须绕过</a>
	<center>
<img src="../img/upload.png">
</body>
</html>