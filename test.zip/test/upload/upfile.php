<?php
if(@$_POST['sub']){
	

		if ($_FILES["file"]["error"] > 0)
		{
			echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
		}
		else
		{
			echo "Upload: " . $_FILES["file"]["name"] . "<br />";
			echo "Type: " . $_FILES["file"]["type"] . "<br />";
			echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
			echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
			$filename = md5(time()).$_FILES["file"]["name"];
			if (file_exists("upload/" . $filename))
			{
				echo $filename . " &#x4E0A;&#x4F20;&#x6210;&#x529F; ";
			}
			else
			{
				move_uploaded_file($_FILES["file"]["tmp_name"],"upload/" .$filename);
				echo "Stored in: " . "upload/" . $filename;
			}
		}

	
}






?>
<meta charset="UTF-8">
<form method="post" enctype ="multipart/form-data"/>
	&#x70B9;&#x8FD9;&#x91CC;&#x4E0A;&#x4F20;&#x6587;&#x4EF6;:<input type="file" name="file"/>
	<input type="submit" value="&#x4E0A;&#x4F20;" name="sub"/>
</form>
