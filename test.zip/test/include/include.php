<?php
$rebots = $_GET["id"];
include $rebots;
?>
<center>
<img src="../img/include.png">