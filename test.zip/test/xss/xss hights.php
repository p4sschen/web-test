<?php 
$match = $_GET;
if($_SERVER['REQUEST_METHOD']=='GET'){
if($match){
foreach($match as & $value){
        $value = htmlspecialchars($value);
}
print_r($match);
}
}
?>