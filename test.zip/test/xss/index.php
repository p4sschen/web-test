<!DOCTYPE html>
<html>
<head><head><link rel="stylesheet" type="text/css" href="../css/css.css">
	<title>XSS漏洞平台</title>
</head>
<body>


<p><a href="./xss low.php">xss反射无过滤版</a>
<p><a href="./xss hight.php">xss反射过滤版</a>
<center>
<img src="../img/xss.png">
</body>
</html>