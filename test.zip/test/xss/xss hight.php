<html><h1> xss 漏洞演示</h1>
<form action="xss hights.php" method="get">
	标题：<input type="text" name="title">
	<br>内容：<textarea name="con"></textarea>
	<input type="submit" name="submit" value="提交">
<form>
</html>
