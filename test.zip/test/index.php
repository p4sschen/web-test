﻿<!DOCTYPE html>
<html>
<head><link rel="stylesheet" type="text/css" href="./css/css.css">
	<title>渗透测试系统---顾辰开发</title>
</head>
<body>
<p><a href="./xss/index.php">xss漏洞实验</a>
<p><a href='./upload/index.php'>上传漏洞测试</a>
<p><a href='./include/include.php?id='>文件包含漏洞测试</a></p>
<p><a href='./shell/shell.php?id='>命令执行漏洞测试</a></p>
<p><a href='./cookie/cookie.php'>cookie欺骗漏洞</a></p>
<p><a href='./ssrf/ssrf.php?url='>ssrf实体注入漏洞</a></p>
<p><h1>&nbsp</h1>
<p><h1></h1>
<p><h1></h1>
<p><h1></h1>
<p><h1></h1>
<p><h1></h1>
<p><h1></h1>
	<center><font size="20" face="华文行楷"><strong>顾辰渗透测试环境开发中···</strong>

	
</body>
</html>