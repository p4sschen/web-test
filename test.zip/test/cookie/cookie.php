<?php


if($_COOKIE['username']){
	echo "登录成功{$_COOKIE['usernme']}";
	
}else {
	echo "登录失败";
}



?>

<meta charset="UTF-8">
<form method='post'>
	<label>帐号：</label><input type='text' name='username'><br>
	<label>密码：</label><input type='password' name='password'><br>
	<input type='submit' value='登录' name='submit'>
</form>
<center>
<img src="../img/cookie.png">